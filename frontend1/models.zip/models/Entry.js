const mongoose = require('mongoose');

const EntrySchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  title: String,
  content: String,
  category: {
    type: String,
    enum: ['cá nhân', 'công việc', 'du lịch', 'ẩm thực', 'tình yêu', 'sáng tạo'],
    required: true
  },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Entry', EntrySchema);
