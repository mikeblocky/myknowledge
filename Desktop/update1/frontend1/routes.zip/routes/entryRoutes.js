const express = require('express');
const router = express.Router();
const {
  createEntry,
  getEntriesByUser,
  getEntriesByCategory,
  updateEntry,
  deleteEntry
} = require('../controllers/entryController');

router.post('/', createEntry);
router.get('/:userId', getEntriesByUser);
router.get('/:userId/category/:category', getEntriesByCategory);
router.put('/:id', updateEntry);
router.delete('/:id', deleteEntry);

module.exports = router;
